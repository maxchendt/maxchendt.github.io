#!/bin/bash

#2016-09-08 20:19  
# ./HexoSite.sh hexo_dir theme
# for examples:
#	./HexoSite.sh /2T/smb/git/hexo next
#	./HexoSite.sh /2T/smb/git/hexo landscape
#修改 站点基本架构设置  title author language url permalink, and theme


#修改站点架构设置 title author language url permalink
sed -ne '/# Site/ {p; r HexoSite' -e ':a; n; /^permalink_defaults/ {p; b}; ba}; p' -i $1/_config.yml

#替换主题
sed "s/^theme.*/theme: $2/" -i $1/_config.yml



